<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>jsontextarea</name>
   <tag></tag>
   <elementGuidId>b980ac18-a611-4583-b3fe-aca633e4a187</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//textarea[@id='textarea']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#textarea</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>textarea</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>textarea</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-area</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>{&quot;type&quot;: &quot;start&quot;, &quot;timestamp&quot;: 1519780251293, &quot;select&quot;: [&quot;min_response_time&quot;, &quot;max_response_time&quot;], &quot;group&quot;: [&quot;os&quot;, &quot;browser&quot;]}
  {&quot;type&quot;: &quot;data&quot;, &quot;timestamp&quot;: 1519780251000, &quot;os&quot;: &quot;linux&quot;, &quot;browser&quot;: &quot;chrome&quot;, &quot;min_response_time&quot;: 0.1, &quot;max_response_time&quot;: 1.3}
  {&quot;type&quot;: &quot;data&quot;, &quot;timestamp&quot;: 1519780252000, &quot;os&quot;: &quot;linux&quot;, &quot;browser&quot;: &quot;chrome&quot;, &quot;min_response_time&quot;: 0.3, &quot;max_response_time&quot;: 1.5}
  {&quot;type&quot;: &quot;data&quot;, &quot;timestamp&quot;: 1519780251000, &quot;os&quot;: &quot;linux&quot;, &quot;browser&quot;: &quot;firefox&quot;, &quot;min_response_time&quot;: 0.1, &quot;max_response_time&quot;: 1.1}
  {&quot;type&quot;: &quot;data&quot;, &quot;timestamp&quot;: 1519780252000, &quot;os&quot;: &quot;linux&quot;, &quot;browser&quot;: &quot;firefox&quot;, &quot;min_response_time&quot;: 0.2, &quot;max_response_time&quot;: 1.7}
  {&quot;type&quot;: &quot;data&quot;, &quot;timestamp&quot;: 1519780251000, &quot;os&quot;: &quot;mac&quot;, &quot;browser&quot;: &quot;firefox&quot;, &quot;min_response_time&quot;: 0.4, &quot;max_response_time&quot;: 1.3}
  {&quot;type&quot;: &quot;data&quot;, &quot;timestamp&quot;: 1519780252000, &quot;os&quot;: &quot;mac&quot;, &quot;browser&quot;: &quot;firefox&quot;, &quot;min_response_time&quot;: 0.5, &quot;max_response_time&quot;: 1.9}
  {&quot;type&quot;: &quot;data&quot;, &quot;timestamp&quot;: 1519780251000, &quot;os&quot;: &quot;mac&quot;, &quot;browser&quot;: &quot;chrome&quot;, &quot;min_response_time&quot;: 0.6, &quot;max_response_time&quot;: 1.8}
  {&quot;type&quot;: &quot;data&quot;, &quot;timestamp&quot;: 1519780252000, &quot;os&quot;: &quot;mac&quot;, &quot;browser&quot;: &quot;chrome&quot;, &quot;min_response_time&quot;: 0.9, &quot;max_response_time&quot;: 2.1}</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;textarea&quot;)</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//textarea[@id='textarea']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div/div/div/textarea</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=concat('Caio', &quot;'&quot;, 's Challenge')])[1]/following::textarea[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Generate Chart'])[1]/preceding::textarea[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Capture object:'])[1]/preceding::textarea[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//textarea</value>
   </webElementXpaths>
</WebElementEntity>
